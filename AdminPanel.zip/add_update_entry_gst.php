<?php include("header_admin.php"); ?>

<?php
	require("dbconn.php");
	$msg=$_GET["msg"];
	$key="";
	
	if(strcmp($msg,"Update GST Entry")==0){
		$key=$_GET['id'];
		$sql="SELECT * FROM entry_gst WHERE entry_gst_id=$key";
		if($result=mysqli_query($conn, $sql)){
			if(mysqli_num_rows($result)>0){
				while($row= mysqli_fetch_array($result)){
					$entry_gst_party_name=$row['cust_name'];
					$entry_gst_year=$row['year'];
					$entry_gst_month=$row['month'];
					$entry_gst_3b=$row['entry_gst_3B'];
					$entry_gst_gstr1=$row['gstr1'];
				}
			}
		}
	}
	
	if(isset($_POST['entry_gst_submit'])){
		$entry_gst_party_name=$_POST['entry_gst_party_name'];
		$entry_gst_year=$_POST['entry_gst_year'];
		$entry_gst_month=$_POST['entry_gst_month'];
		$entry_gst_3b=$_POST['entry_gst_3b'];
		$entry_gst_gstr1=$_POST['entry_gst_gstr1'];
		
		$sql="INSERT INTO entry_gst (cust_name, year, month, entry_gst_3B, gstr1) VALUES ('$entry_gst_party_name', '$entry_gst_year', '$entry_gst_month', '$entry_gst_3b', '$entry_gst_gstr1')";
		
		$result=mysqli_query($conn, $sql);
		if($result){
			echo '<script type="text/javascript">
					location.replace("entry_gst.php");
				  </script>';
		}
		mysqli_close($conn);
	}
	
	if(isset($_POST["entry_gst_update"])){
		
		$entry_gst_party_name=$_POST['entry_gst_party_name'];
		$entry_gst_year=$_POST['entry_gst_year'];
		$entry_gst_month=$_POST['entry_gst_month'];
		$entry_gst_3b=$_POST['entry_gst_3b'];
		$entry_gst_gstr1=$_POST['entry_gst_gstr1'];		
					
		$sql = "UPDATE entry_gst SET cust_name='$entry_gst_party_name', year='$entry_gst_year', month='$entry_gst_month', entry_gst_3B='$entry_gst_3b', gstr1='$entry_gst_gstr1' WHERE entry_gst_id=$key";
					
		$result=mysqli_query($conn, $sql);
		if($result){
			echo '<script type="text/javascript">
					location.replace("entry_gst.php");
				  </script>';
			}
		mysqli_close($conn);
	}
?>

<!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                            <h3 class="title-5 m-b-35"><?= $msg ?></h3>
                            <div class="col-lg-9">
                                <div class="card">
									<div class="card-body card-block">
                                        <form action="" method="post" enctype="multipart/form-data" class="form-horizontal">
                                            
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Party Name: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <select name="entry_gst_party_name" id="select" class="form-control">
                                                        <option value="">Select Name</option>
														<?php
															require("dbconn.php");
															$query="SELECT customer_name FROM customer_ ORDER BY customer_name";
															if($result=mysqli_query($conn, $query)){
																if(mysqli_num_rows($result)>0){
																	while($row= mysqli_fetch_array($result)){
																		echo "<option value='".$row['customer_name']."'>";
																		echo $row['customer_name'];
																		echo "</option>";
																	}
																}
															}
														?>
                                                    </select>
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Year: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <select name="entry_gst_year" id="select" class="form-control">
														<option value="2020-21">2020-21</option>
                                                        <option value="2021-22">2021-22</option>
                                                    </select>
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Month: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <select name="entry_gst_month" id="select" class="form-control">
														<option value="April">April</option>
                                                        <option value="May">May</option>
														<option value="June">June</option>
														<option value="July">July</option>
														<option value="August">August</option>
														<option value="September">September</option>
														<option value="October">October</option>
														<option value="November">November</option>
														<option value="December">December</option>
														<option value="January">January</option>
														<option value="February">February</option>
														<option value="March">March</option>
                                                    </select>
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">GST3B: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="date" name="entry_gst_3b" class="form-control" > 
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">GSTR1: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="date" name="entry_gst_gstr1" class="form-control" > 
                                                </div>
                                            </div>
											
											<div class="card-footer">
											
												<?php
													if(strcmp($msg,"Update GST Entry")==0){
														echo "<button type='submit' name='entry_gst_submit' class='btn btn-primary btn-sm' disabled>";
														echo "<i class='fa fa-dot-circle-o'></i> Submit</button>";
														echo "<button type='submit'  name='entry_gst_update' class='btn btn-warning btn-sm'>";
														echo "<i class='fa fa-dot-circle-o'></i> Update</button>";
													}else{
														echo "<button type='submit' name='entry_gst_submit' class='btn btn-primary btn-sm'>";
														echo "<i class='fa fa-dot-circle-o'></i> Submit</button>";
														echo "<button type='submit'  name='entry_gst_update' class='btn btn-warning btn-sm' disabled>";
														echo "<i class='fa fa-dot-circle-o'></i> Update</button>";
													}
												?>
												<button type="reset" class="btn btn-danger btn-sm">
													<i class="fa fa-ban"></i> Reset
												</button>
											</div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

<?php include("footer_admin.php"); ?>