<?php include_once("header_admin.php");?>
			
			<style> .gst_hide { display: none;} </style>
			<script>
				function hide1(){
					document.getElementById('div_gst_mode').style.display ='none';
				}
				function show1(){
					document.getElementById('div_gst_mode').style.display = 'block';
				}
			</script>
			
			<?php
				require("dbconn.php");
				$msg=$_GET["msg"];
				$key="";
				$cust_name="";
				$cust_gst_num="";
				$cust_pan_num="";
				$cust_file_num="";
				$cust_email="";
				$cust_mob_1="";
				$cust_mob_2="";
				$cust_address="";
				$cust_city="";
				$cust_dsc_date="";
				$cust_cont_person="";
				$cust_advocate="";
				$cust_gst_mode="";
				$cust_agree="";
				$cust_status="Active";
				
				if(strcmp($msg,"Deactivate Customer")==0){
					$key=$_GET['id'];
					$sql = "UPDATE customer_ SET status='Deactivate' WHERE cust_id=$key";
					$result=mysqli_query($conn, $sql);
					if($result){
						echo '<script type="text/javascript">
								location.replace("customer.php");
							  </script>';
					}
					mysqli_close($conn);
				}
				
				if(strcmp($msg,"Update Customer")==0){
					$key=$_GET['id'];
					$sql="SELECT * FROM customer_ WHERE cust_id=$key";
					if($result=mysqli_query($conn, $sql)){
						if(mysqli_num_rows($result)>0){
							while($row= mysqli_fetch_array($result)){
								$cust_name=$row['customer_name'];
								$cust_gst_num=$row['gst_number'];
								$cust_pan_num=$row['pan_number'];
								$cust_file_num=$row['file_number'];
								$cust_email=$row['emailid'];
								$cust_mob_1=$row['mob_num_1'];
								$cust_mob_2=$row['mob_num_2'];
								$cust_address=$row['address'];
								$cust_city=$row['city'];
								$cust_dsc_date=$row['dsc_date'];
								$cust_cont_person=$row['contact_person'];
								$cust_advocate=$row['adv_name'];
								$cust_gst_mode=$row['gst_mode'];
								$cust_agree=$row['agree'];
							}
						}
					}
				}
				
				if(isset($_POST["cust_submit"])){
					$cust_name = $_POST["cust_name"];
					$cust_gst_num = $_POST["cust_gst_num"];
					$cust_pan_num = $_POST["cust_pan_num"];
					$cust_file_num = $_POST["cust_file_num"];
					$cust_email = $_POST["cust_email"];
					$cust_mob_1 = $_POST["cust_mob_1"];
					$cust_mob_2 = $_POST["cust_mob_2"];
					$cust_address = $_POST["cust_address"];
					$cust_city = $_POST["cust_city"];
					$cust_category = $_POST["cust_category"];
					$cust_dsc_date = $_POST["cust_dsc_date"];
					$cust_cont_person = $_POST["cust_cont_person"];
					$cust_advocate = $_POST["cust_advocate"];
					$cust_gst_mode = $_POST["cust_gst_mode"];
					$cust_agree = $_POST["cust_agree"];
		
					$sql = "INSERT INTO customer_(customer_name, gst_number, pan_number, file_number, adv_name, emailid, mob_num_1, mob_num_2, address, city, gst_mode, category, dsc_date, contact_person, agree, status) VALUES ('$cust_name', '$cust_gst_num', '$cust_pan_num', '$cust_file_num', '$cust_advocate', '$cust_email', '$cust_mob_1', '$cust_mob_2', '$cust_address', '$cust_city', '$cust_gst_mode', '$cust_category', '$cust_dsc_date', '$cust_cont_person', '$cust_agree', '$cust_status')"; 
		
					$result=mysqli_query($conn, $sql);
					if($result){
						echo '<script type="text/javascript">
								location.replace("customer.php");
							  </script>';
					}
		
					mysqli_close($conn);
				}
				
				if(isset($_POST["cust_update"])){
					$cust_name = $_POST["cust_name"];
					$cust_gst_num = $_POST["cust_gst_num"];
					$cust_pan_num = $_POST["cust_pan_num"];
					$cust_file_num = $_POST["cust_file_num"];
					$cust_email = $_POST["cust_email"];
					$cust_mob_1 = $_POST["cust_mob_1"];
					$cust_mob_2 = $_POST["cust_mob_2"];
					$cust_address = $_POST["cust_address"];
					$cust_city = $_POST["cust_city"];
					$cust_category = $_POST["cust_category"];
					$cust_dsc_date = $_POST["cust_dsc_date"];
					$cust_cont_person = $_POST["cust_cont_person"];
					$cust_advocate = $_POST["cust_advocate"];
					$cust_gst_mode = $_POST["cust_gst_mode"];
					$cust_agree = $_POST["cust_agree"];
					
					$sql = "UPDATE customer_ SET customer_name='$cust_name', gst_number='$cust_gst_num', pan_number='$cust_pan_num', file_number='$cust_file_num', adv_name='$cust_advocate', emailid='$cust_email', mob_num_1='$cust_mob_1', mob_num_2='$cust_mob_2', address='$cust_address', city='$cust_city', gst_mode='$cust_gst_mode', category='$cust_category', dsc_date='$cust_dsc_date', contact_person='$cust_cont_person', agree='$cust_agree' WHERE cust_id=$key";
					
					$result=mysqli_query($conn, $sql);
					if($result){
						echo '<script type="text/javascript">
								location.replace("customer.php");
							  </script>';
					}
					mysqli_close($conn);
				}
				
			?>

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                            <h3 class="title-5 m-b-35"><?= $msg ?></h3>
                            <div class="col-lg-9">
                                <div class="card">
									<div class="card-body card-block">
                                        <form action="" method="post" enctype="multipart/form-data" class="form-horizontal">
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Customer Name: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" name="cust_name" value="<?= $cust_name ?>" class="form-control" required>
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">GST Number: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" name="cust_gst_num" value="<?= $cust_gst_num ?>" class="form-control" required>
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">PAN Number: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" name="cust_pan_num" value="<?= $cust_pan_num ?>" class="form-control" required>
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">File Number: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" name="cust_file_num" value="<?= $cust_file_num ?>" class="form-control" required>
                                                </div>
                                            </div>
											
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="email-input" class=" form-control-label">Email Id: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="email" name="cust_email" value="<?= $cust_email ?>" class="form-control" required>
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Mobile Number 1: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="number" name="cust_mob_1" value="<?= $cust_mob_1 ?>" class="form-control" required>
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Mobile Number 2: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="number" name="cust_mob_2" value="<?= $cust_mob_2 ?>" class="form-control" required>
                                                </div>
                                            </div>
											
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="textarea-input" class=" form-control-label">Address: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <textarea name="cust_address" rows="6" class="form-control" required><?= $cust_address ?></textarea>
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">City: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" name="cust_city" value="<?= $cust_city ?>" class="form-control" required>
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="select" class=" form-control-label">Advocate: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <select name="cust_advocate" id="select" class="form-control">
                                                        <option value="Self">Self</option>
														<?php
															require("dbconn.php");
															$query="SELECT name FROM gstadvocate_ UNION SELECT name FROM itadvocate_ ORDER BY name";
															if($result=mysqli_query($conn, $query)){
																if(mysqli_num_rows($result)>0){
																	while($row= mysqli_fetch_array($result)){
																		echo "<option value='".$row['name']."'>";
																		echo $row['name'];
																		echo "</option>";
																	}
																}
															}
														?>
                                                    </select>
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label class=" form-control-label">GST: </label>
                                                </div>
												<div class="col col-md-9">
                                                    <div class="form-check">
                                                        <div class="radio">
                                                            <label for="gst_yes" class="form-check-label ">
                                                                <input type="radio" id="gst_yes" name="cust_gst" value="Yes" class="form-check-input" onclick="show1();">Yes
                                                            </label>
                                                        </div>
                                                        <div class="radio">
                                                            <label for="gst_no" class="form-check-label ">
                                                                <input type="radio" id="gst_no" name="cust_gst" value="No" class="form-check-input" onclick="hide1();">No
                                                            </label>
                                                        </div>
													</div>
												</div>
											</div>
											
											<div class="row form-group gst_hide" id="div_gst_mode">
                                                <div class="col col-md-3" >
                                                    <label for="select" class=" form-control-label">GST Mode: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <select name="cust_gst_mode" id="select" class="form-control">
                                                        <option value="Monthly">Monthly</option>
                                                        <option value="Quarterly">Quarterly</option>
                                                    </select>
                                                </div>
                                            </div>
											
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="select" class=" form-control-label">Category: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <select name="cust_category" id="select" class="form-control">
                                                        <option value="Regular">Regular</option>
                                                        <option value="Composition">Composition</option>
                                                    </select>
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">DSC Date: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="date" name="cust_dsc_date" value="<?= $cust_dsc_date ?>" class="form-control" required> 
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Contact Person: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" name="cust_cont_person" value="<?= $cust_cont_person ?>" class="form-control" required>
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label class=" form-control-label">Agree: </label>
                                                </div>
												<div class="col col-md-9">
                                                    <div class="form-check">
                                                        <div class="radio">
                                                            <label for="radio3" class="form-check-label ">
                                                                <input type="radio" id="radio3" name="cust_agree" value="Yes" class="form-check-input">Yes
                                                            </label>
                                                        </div>
                                                        <div class="radio">
                                                            <label for="radio4" class="form-check-label ">
                                                                <input type="radio" id="radio4" name="cust_agree" value="No" class="form-check-input">No
                                                            </label>
                                                        </div>
													</div>
												</div>
											</div>
											
											<div class="card-footer">
											
												<?php
													if(strcmp($msg,"Update Customer")==0){
														echo "<button type='submit' name='cust_submit' class='btn btn-primary btn-sm' disabled>";
														echo "<i class='fa fa-dot-circle-o'></i> Submit</button>";
														echo "<button type='submit'  name='cust_update' class='btn btn-warning btn-sm'>";
														echo "<i class='fa fa-dot-circle-o'></i> Update</button>";
													}else{
														echo "<button type='submit' name='cust_submit' class='btn btn-primary btn-sm'>";
														echo "<i class='fa fa-dot-circle-o'></i> Submit</button>";
														echo "<button type='submit'  name='cust_update' class='btn btn-warning btn-sm' disabled>";
														echo "<i class='fa fa-dot-circle-o'></i> Update</button>";
													}
												?>
												
												<button type="reset" class="btn btn-danger btn-sm">
													<i class="fa fa-ban"></i> Reset
												</button>
											</div>
                                        </form>
                                    </div> 
                                </div>
                            </div>
                        </div>
                        
                            
	<?php include("footer_admin.php"); ?>