<?php include("header_admin.php"); ?>


            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <!-- DATA TABLE -->
                                <h3 class="title-5 m-b-35">GST Entry</h3>
                                <div class="table-data__tool">
                                    <div class="table-data__tool-right">
									<a href="add_update_entry_gst.php?msg=New GST Entry">
                                        <button class="au-btn au-btn-icon au-btn--green au-btn--small">
                                            <i class="zmdi zmdi-plus"></i>Add GST Entry
										</button>
									</a>
                                    </div>
                                </div>
                                <div class="table-responsive table--no-card m-b-30">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
												<th>Sr.No</th>
                                                <th>Party Name</th>
                                                <th>Year</th>
                                                <th>Month</th>
                                                <th>GST3B</th>
												<th>GSTR1</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
										
											require("dbconn.php");
											$sql = "SELECT * FROM entry_gst";
											$i=1;
											if($result=mysqli_query($conn,$sql)){
												if(mysqli_num_rows($result)>0){
													while($row= mysqli_fetch_array($result)){
															echo "<tr class='tr-shadow'>";
																echo "<td>".$i++."</td>";
																echo "<td>".$row['cust_name']."</td>";
																echo "<td>".$row['year']."</td>";
																echo "<td>".$row['month']."</td>";
																echo "<td>".$row['entry_gst_3B']."</td>";
																echo "<td>".$row['gstr1']."</td>";
																echo "<td>";
																	echo "<div class='table-data-feature'>";
																		echo "<a href='add_update_entry_gst.php?msg=Update GST Entry&id=".$row['entry_gst_id']."'><button class='item' data-toggle='tooltip' data-placement='top' title='Edit'>";
																		echo "<i class='zmdi zmdi-edit'></i>";
																		echo "</button></a>";
																		echo "<a href='delete_entry_gst.php?id=".$row['entry_gst_id']."'><button class='item' data-toggle='tooltip' data-placement='top' title='Delete'>";
																		echo "<i class='zmdi zmdi-delete'></i>";
																		echo "</button></a>";
																	echo "</div>";
																echo "</td>";
															echo "</tr>";
													}
												}
											}
											
										?>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE -->
                            </div>
                        
<?php include("footer_admin.php"); ?>