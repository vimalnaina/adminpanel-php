<?php
	$host="localhost";
	$username="root";
	$password="";
	$db="admindb";
	$conn=mysqli_connect("$host","$username","$password","$db");
?>