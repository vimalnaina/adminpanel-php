<?php include("header_admin.php"); ?>

<?php
	require("dbconn.php");
	$msg=$_GET["msg"];
	$key="";
	
	if(strcmp($msg,"Update ITR Pending Entry")==0){
		$key=$_GET['id'];
		$sql="SELECT * FROM entry_itr_pending WHERE entry_itr_id=$key";
		if($result=mysqli_query($conn, $sql)){
			if(mysqli_num_rows($result)>0){
				while($row= mysqli_fetch_array($result)){
					$entry_itr_pending_party_name=$row['cust_name'];
					$entry_itr_pending_call=$row['itr_call'];
					$entry_itr_pending_wp=$row['itr_whatsapp'];
					$entry_itr_pending_sms=$row['itr_sms'];
					$entry_itr_pending_details=$row['pending_details'];
				}
			}
		}
	}
	
	if(isset($_POST['entry_itr_pending_submit'])){
		$entry_itr_pending_party_name=$_POST['entry_itr_pending_party_name'];
		$entry_itr_pending_call=$_POST['entry_itr_pending_call'];
		$entry_itr_pending_wp=$_POST['entry_itr_pending_wp'];
		$entry_itr_pending_sms=$_POST['entry_itr_pending_sms'];
		$entry_itr_pending_details=$_POST['entry_itr_pending_details'];
		
		$sql="INSERT INTO entry_itr_pending (cust_name, itr_call, itr_whatsapp, itr_sms, pending_details) VALUES ('$entry_itr_pending_party_name', '$entry_itr_pending_call', '$entry_itr_pending_wp', '$entry_itr_pending_sms', '$entry_itr_pending_details')";
		
		$result=mysqli_query($conn, $sql);
		if($result){
			echo '<script type="text/javascript">
					location.replace("entry_itr_pending.php");
				  </script>';
		}
		mysqli_close($conn);
	}
	
	if(isset($_POST["entry_itr_pending_update"])){
		
		$entry_itr_pending_party_name=$_POST['entry_itr_pending_party_name'];
		$entry_itr_pending_call=$_POST['entry_itr_pending_call'];
		$entry_itr_pending_wp=$_POST['entry_itr_pending_wp'];
		$entry_itr_pending_sms=$_POST['entry_itr_pending_sms'];
		$entry_itr_pending_details=$_POST['entry_itr_pending_details'];
					
		$sql = "UPDATE entry_itr_pending SET cust_name='$entry_itr_pending_party_name', itr_call='$entry_itr_pending_call', itr_whatsapp='$entry_itr_pending_wp', itr_sms='$entry_itr_pending_sms', pending_details='$entry_itr_pending_details' WHERE entry_itr_id=$key";
					
		$result=mysqli_query($conn, $sql);
		if($result){
			echo '<script type="text/javascript">
					location.replace("entry_itr_pending.php");
				  </script>';
		}
		mysqli_close($conn);
	}
?>

<!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                            <h3 class="title-5 m-b-35"><?= $msg ?></h3>
                            <div class="col-lg-9">
                                <div class="card">
									<div class="card-body card-block">
                                        <form action="" method="post" enctype="multipart/form-data" class="form-horizontal">
                                            
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Party Name: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <select name="entry_itr_pending_party_name" id="select" class="form-control">
                                                        <option value="">Select Name</option>
														<?php
															require("dbconn.php");
															$query="SELECT customer_name FROM customer_ ORDER BY customer_name";
															if($result=mysqli_query($conn, $query)){
																if(mysqli_num_rows($result)>0){
																	while($row= mysqli_fetch_array($result)){
																		echo "<option value='".$row['customer_name']."'>";
																		echo $row['customer_name'];
																		echo "</option>";
																	}
																}
															}
														?>
                                                    </select>
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Call: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="date" name="entry_itr_pending_call" class="form-control" > 
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Whatsapp: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" name="entry_itr_pending_wp" class="form-control" required>
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">SMS: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" name="entry_itr_pending_sms" class="form-control" required>
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="textarea-input" class=" form-control-label">Pending Details: </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <textarea name="entry_itr_pending_details" rows="6" class="form-control"></textarea>
                                                </div>
                                            </div>
											
											<div class="card-footer">
											
												<?php
													if(strcmp($msg,"Update ITR Pending Entry")==0){
														echo "<button type='submit' name='entry_itr_pending_submit' class='btn btn-primary btn-sm' disabled>";
														echo "<i class='fa fa-dot-circle-o'></i> Submit</button>";
														echo "<button type='submit'  name='entry_itr_pending_update' class='btn btn-warning btn-sm'>";
														echo "<i class='fa fa-dot-circle-o'></i> Update</button>";
													}else{
														echo "<button type='submit' name='entry_itr_pending_submit' class='btn btn-primary btn-sm'>";
														echo "<i class='fa fa-dot-circle-o'></i> Submit</button>";
														echo "<button type='submit'  name='entry_itr_pending_update' class='btn btn-warning btn-sm' disabled>";
														echo "<i class='fa fa-dot-circle-o'></i> Update</button>";
													}
												?>
												<button type="reset" class="btn btn-danger btn-sm">
													<i class="fa fa-ban"></i> Reset
												</button>
											</div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
<?php include("footer_admin.php"); ?>