<?php
	$host="localhost";
	$username="customtw_shreeji";
	$password="pass_shreeji";
	$db="customtw_shreejidb";
	$conn=mysqli_connect("$host","$username","$password","$db");
?>